#include "Mage.h"

Mage::Mage()
{
  this->unitClass = "Magic";
  this->damage = 5;
  this->health = 80;
}
