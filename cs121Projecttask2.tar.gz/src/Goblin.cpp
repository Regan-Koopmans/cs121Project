#include "Goblin.h"

Goblin::Goblin()
{
  this->unitClass = "Piercing";
  this->damage = 12;
  this->health = 50;
}
