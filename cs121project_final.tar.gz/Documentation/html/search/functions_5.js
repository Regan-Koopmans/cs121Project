var searchData=
[
  ['gamemaster',['GameMaster',['../class_game_master.html#af68133fd8969aa4ed20ad3009ad8cdb2',1,'GameMaster']]],
  ['getclass',['getClass',['../class_unit.html#a4c4dde0419950aa3b44302bbff2af810',1,'Unit']]],
  ['getdamage',['getDamage',['../class_unit.html#a7b0dbed96660669a2234b715018781fa',1,'Unit']]],
  ['gethealth',['getHealth',['../class_unit.html#a610a98a68a3e99227b15af4161f26b70',1,'Unit']]],
  ['getmapsizex',['getMapSizeX',['../class_map.html#a2960ea8c9260e0b6e59860c3a29b1689',1,'Map']]],
  ['getmapsizey',['getMapSizeY',['../class_map.html#a47c7f7c1422f039670062c01dbb95c7f',1,'Map']]],
  ['getmaptile',['getMapTile',['../class_map.html#aa2e6440872eabd43083a73909ba60464',1,'Map']]],
  ['getsize',['getSize',['../class_team.html#a8690d30ee7ef4bb392a785a4ad5c9c2e',1,'Team']]],
  ['getunitat',['getUnitAt',['../class_team.html#a453dc0ebd17df8f83fd619dd898287f8',1,'Team']]],
  ['goblin',['Goblin',['../class_goblin.html#a22d43a81f99697e13d13a0c56fae9bc4',1,'Goblin']]]
];
