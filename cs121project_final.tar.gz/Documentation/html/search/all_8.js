var searchData=
[
  ['locateunit',['locateUnit',['../class_master.html#a355cd520378a1ee4bbf340badf4163ae',1,'Master::locateUnit(Unit *inputUnit)'],['../class_master.html#a1401033a876ae9e4b38e5879537c5b2a',1,'Master::locateUnit(int row, int col)']]]
];
