var searchData=
[
  ['removedestroyedunits',['removeDestroyedUnits',['../class_game_master.html#a324bec472bdb5e313e7b70d451b9eeae',1,'GameMaster::removeDestroyedUnits()'],['../class_master.html#aadca1629b9756f20d101569fc783fbca',1,'Master::removeDestroyedUnits()']]],
  ['requestfreespace',['requestFreeSpace',['../class_game_master.html#a58aea57e4aac40805bbd71d19e8da2ac',1,'GameMaster::requestFreeSpace()'],['../class_master.html#a3ddcc34d8f2cbf14a247b7021e6cb57a',1,'Master::requestFreeSpace()']]]
];
