var searchData=
[
  ['takedamage',['takeDamage',['../class_team.html#aad3a08035daa8dc5abe0795a010d141d',1,'Team']]],
  ['team',['Team',['../class_team.html#a23a02be0438b0603c7f811a0605ce207',1,'Team']]],
  ['thief',['Thief',['../class_thief.html#aa27752dd9c628bf41d297fedee59c2df',1,'Thief']]],
  ['turn',['turn',['../class_computer_team.html#aefc2941cfd59f175dd200daf2b025d21',1,'ComputerTeam::turn()'],['../class_human_team.html#a6030c5d87d9e9c684073a62db8bb39f0',1,'HumanTeam::turn()'],['../class_single_player.html#a9692093f7703200a431a3010db74cf5f',1,'SinglePlayer::turn()'],['../class_team.html#a016ca6682fff81eac2301bd6bf80db88',1,'Team::turn()']]]
];
