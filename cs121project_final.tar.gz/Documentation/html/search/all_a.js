var searchData=
[
  ['notify',['notify',['../class_master.html#aa22e3edd94d966011e1874a2bce1d664',1,'Master']]]
];
