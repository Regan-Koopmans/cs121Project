var searchData=
[
  ['detachteam',['detachTeam',['../class_game_master.html#a638ef26b4c968ba97114ffbbe55810c8',1,'GameMaster::detachTeam()'],['../class_master.html#a876e27a128fd3ce416e06f87097df2ae',1,'Master::detachTeam()']]]
];
