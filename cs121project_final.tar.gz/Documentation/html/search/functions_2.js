var searchData=
[
  ['clone',['clone',['../class_monster.html#a1ee9cabba47d15d4e196d19561250ee0',1,'Monster::clone()'],['../class_player.html#ad690ac4f9f851298abeb0955321ea29e',1,'Player::clone()'],['../class_unit.html#add809c0669cb6b08afae913da60c4cc1',1,'Unit::clone()']]],
  ['computerteam',['ComputerTeam',['../class_computer_team.html#a51fe84b449942ad27c3430baf739c88f',1,'ComputerTeam']]],
  ['createmonster',['createMonster',['../class_bludgeoning_factory.html#aac731068b267c290aa7d0b3968cf7d1d',1,'BludgeoningFactory::createMonster()'],['../class_magic_factory.html#aaef72871585cca14e5b847fc44ce3c2b',1,'MagicFactory::createMonster()'],['../class_piercing_factory.html#a042235a24b114b8b66e3e7733109e504',1,'PiercingFactory::createMonster()'],['../class_unit_factory.html#a5c34317957c2500e571dae72bcb0ef3e',1,'UnitFactory::createMonster()']]],
  ['createplayer',['createPlayer',['../class_bludgeoning_factory.html#adb269785fcab1a468aabe771cf4f4336',1,'BludgeoningFactory::createPlayer()'],['../class_magic_factory.html#a3021b979bd991e32e311c8869d500b46',1,'MagicFactory::createPlayer()'],['../class_piercing_factory.html#a3a2f3736e85a5c4b0ad0160b1b34d796',1,'PiercingFactory::createPlayer()'],['../class_unit_factory.html#ad0c4ed547dcb38f6176a660850d405c6',1,'UnitFactory::createPlayer()']]]
];
