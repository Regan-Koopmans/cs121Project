var searchData=
[
  ['computerteam',['ComputerTeam',['../class_computer_team.html',1,'']]]
];
