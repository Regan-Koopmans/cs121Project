#include "Ogre.h"

Ogre::Ogre()
{
  this->unitClass = "Bludgeoning";
  this->damage = 5;
  this->health = 120;
}
