#include "Thief.h"

Thief::Thief()
{
  this->unitClass = "Piercing";
  this->damage = 10;
  this->health = 60;
}
