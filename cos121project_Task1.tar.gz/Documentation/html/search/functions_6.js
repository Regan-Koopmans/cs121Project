var searchData=
[
  ['setclass',['setClass',['../class_unit.html#a0da561786edca63a3282b60a1203ef61',1,'Unit']]],
  ['setdamage',['setDamage',['../class_unit.html#ac57bb8bbddb45b4b55f841e43f96fe0b',1,'Unit']]],
  ['sethealth',['setHealth',['../class_unit.html#ac763191e46e663938479a9be72c5bd39',1,'Unit']]],
  ['soldier',['Soldier',['../class_soldier.html#ad3144b22a146ef85eaff30a2a5ab78c0',1,'Soldier']]]
];
