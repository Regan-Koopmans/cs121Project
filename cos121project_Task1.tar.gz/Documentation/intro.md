#Documentation

This is the folder in which we will put all UML diagrams and Doxygen
documentation. 
