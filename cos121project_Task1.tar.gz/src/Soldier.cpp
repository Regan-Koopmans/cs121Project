#include "Soldier.h"

Soldier::Soldier()
{
  this->unitClass = "Bludgeoning";
  this->damage = 8;
  this->health = 100;
}
