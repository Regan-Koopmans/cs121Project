var searchData=
[
  ['getclass',['getClass',['../class_unit.html#a4c4dde0419950aa3b44302bbff2af810',1,'Unit']]],
  ['getdamage',['getDamage',['../class_unit.html#a7b0dbed96660669a2234b715018781fa',1,'Unit']]],
  ['gethealth',['getHealth',['../class_unit.html#a610a98a68a3e99227b15af4161f26b70',1,'Unit']]],
  ['goblin',['Goblin',['../class_goblin.html',1,'Goblin'],['../class_goblin.html#a22d43a81f99697e13d13a0c56fae9bc4',1,'Goblin::Goblin()']]]
];
