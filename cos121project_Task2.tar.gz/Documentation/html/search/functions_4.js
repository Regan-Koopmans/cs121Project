var searchData=
[
  ['mage',['Mage',['../class_mage.html#a9d7d4455a6fa1f8e35117e0dc301d082',1,'Mage']]]
];
