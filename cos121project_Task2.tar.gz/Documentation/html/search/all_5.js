var searchData=
[
  ['mage',['Mage',['../class_mage.html',1,'Mage'],['../class_mage.html#a9d7d4455a6fa1f8e35117e0dc301d082',1,'Mage::Mage()']]],
  ['magicfactory',['MagicFactory',['../class_magic_factory.html',1,'']]],
  ['monster',['Monster',['../class_monster.html',1,'']]]
];
