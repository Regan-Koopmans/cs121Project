var searchData=
[
  ['soldier',['Soldier',['../class_soldier.html',1,'']]]
];
