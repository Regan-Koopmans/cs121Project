#include "DungeonGame.h"

void DungeonGame::beginGame()
{
  gameMaster.playGame();
}

DungeonGame::~DungeonGame()
{

}
