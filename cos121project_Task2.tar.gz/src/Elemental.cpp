#include "Elemental.h"

Elemental::Elemental()
{
  this->unitClass = "Magic";
  this->damage = 4;
  this->health = 85;
}
