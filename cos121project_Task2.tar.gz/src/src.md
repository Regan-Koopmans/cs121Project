
#Source Folder

This folder contains all source files for the project. :sunglasses:

##Structure of the Project

This is the structure of the project, when we are complete with a task we
can put a :heavy_check_mark: next to it. I think that we should work outside the
folders, and then copy files into the folders when the tasks are done.

###Task1

This task is concerned with the unit hierarchy, and therefore includes the
creational design patterns.

###Task2

This task is about the Game Master and the U

###Task3

This task is concerned with tying the whole system together.

###Task4

I have no idea what we have to do for task 4 yet :joy:

###Task5 (Bonus)

This is a bonus task for getting graphics to work in the game.
